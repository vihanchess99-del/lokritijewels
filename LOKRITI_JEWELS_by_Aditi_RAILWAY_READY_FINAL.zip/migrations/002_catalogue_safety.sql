ALTER TABLE products ADD COLUMN deleted_at DATETIME NULL
;
ALTER TABLE products ADD INDEX idx_products_deleted (deleted_at)
;
