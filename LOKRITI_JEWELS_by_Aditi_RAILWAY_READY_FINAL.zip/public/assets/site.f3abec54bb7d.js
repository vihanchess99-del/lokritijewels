let products = [];
let productMeta = { total: 0, page: 1, pages: 0 };
const WISHLIST_KEY = 'lokriti_wishlist_v1';
let currency = localStorage.getItem('lokriti_currency') || 'INR';
let rates = { INR: 1 };
const symbols = { INR: '₹', USD: '$', GBP: '£', EUR: '€', AED: 'د.إ', CAD: 'C$', AUD: 'A$' };
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
function money(v) { const rate = Number(rates[currency] || 1); return `${symbols[currency] || '₹'}${(Number(v) * rate).toLocaleString(undefined, { maximumFractionDigits: 0 })}`; }
function wishlist() { try { return JSON.parse(localStorage.getItem(WISHLIST_KEY) || '[]'); } catch { return []; } }
function toggleWishlist(id) { const w = wishlist(); const i = w.indexOf(id); if (i >= 0) { w.splice(i, 1); toast('Removed from your saved pieces'); } else { w.push(id); toast('Saved to your wishlist'); } localStorage.setItem(WISHLIST_KEY, JSON.stringify(w)); document.dispatchEvent(new CustomEvent('lokriti:wishlist')); }
function isWishlisted(id) { return wishlist().includes(id); }
function toast(msg) { let t = $('.toast'); if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); } t.textContent = msg; t.classList.add('show'); clearTimeout(window._toast); window._toast = setTimeout(() => t.classList.remove('show'), 2600); }

async function loadPublicConfig() {
  try {
    const r = await fetch('/api/config', { cache: 'no-store' });
    if (!r.ok) return;
    const c = await r.json();
    if (c.ga4Id && !window.dataLayer) {
      window.dataLayer = window.dataLayer || [];
      window.gtag = function () { window.dataLayer.push(arguments); };
      window.gtag('js', new Date()); window.gtag('config', c.ga4Id, { anonymize_ip: true });
      const s = document.createElement('script'); s.async = true; s.src = `https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(c.ga4Id)}`; document.head.appendChild(s);
    }
    if (c.metaPixelId && !window.fbq) {
      !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
      window.fbq('init', c.metaPixelId); window.fbq('track', 'PageView');
    }
  } catch {}
}

async function loadRates() {
  try {
    const r = await fetch('/api/rates', { cache: 'no-store' });
    if (!r.ok) return;
    const j = await r.json();
    if (j.rates) rates = { INR: 1, ...j.rates };
  } catch {}
}

function initGlobal() {
  $$('.currency').forEach(s => {
    s.value = currency;
    s.addEventListener('change', () => { currency = s.value; localStorage.setItem('lokriti_currency', currency); renderProducts(new URLSearchParams(location.search).get('category') || 'All'); renderSearch($('.search-panel input')?.value || ''); });
  });
  $('.mobile-toggle')?.addEventListener('click', () => { const nav = $('.mobile-nav'); nav?.classList.toggle('open'); const b = $('.mobile-toggle'); b?.setAttribute('aria-expanded', nav?.classList.contains('open') ? 'true' : 'false'); });
  $('.search-trigger')?.addEventListener('click', () => { $('.search-panel')?.classList.add('open'); $('.search-panel input')?.focus(); });
  $('.search-panel .close')?.addEventListener('click', () => $('.search-panel')?.classList.remove('open'));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') $('.search-panel')?.classList.remove('open'); });
  const si = $('.search-panel input'); si?.addEventListener('input', () => renderSearch(si.value));
  $$('.filter').forEach(b => b.addEventListener('click', () => { $$('.filter').forEach(x => x.classList.remove('active')); b.classList.add('active'); const category = b.dataset.category || 'All'; const url = new URL(location.href); if (category === 'All') url.searchParams.delete('category'); else url.searchParams.set('category', category); history.replaceState({}, '', url); loadProducts(category); }));
  document.addEventListener('click', e => { const link = e.target.closest('[data-search-id]'); if (link) { e.preventDefault(); location.href = `/products/${encodeURIComponent(link.dataset.searchId)}`; } });
  loadProducts(new URLSearchParams(location.search).get('category') || 'All');
}

async function loadProducts(category = 'All', q = '') {
  const params = new URLSearchParams({ page: '1', limit: '24' });
  if (category && category !== 'All') params.set('category', category);
  if (q) params.set('q', q);
  try {
    const r = await fetch(`/api/products?${params.toString()}`, { cache: 'no-store' });
    if (!r.ok) throw new Error();
    const data = await r.json();
    products = Array.isArray(data) ? data : (data.items || []);
    productMeta = Array.isArray(data) ? { total: products.length, page: 1, pages: 1 } : data;
  } catch { products = []; productMeta = { total: 0, page: 1, pages: 0 }; }
  renderProducts(category);
  renderSearch($('.search-panel input')?.value || '');
}
function renderProducts(cat = 'All') {
  const grid = $('.product-grid'); if (!grid) return;
  const filtered = cat === 'All' ? products : products.filter(p => p.category === cat);
  if (!filtered.length) { grid.innerHTML = `<div class="empty-products"><div class="eyebrow" style="color:var(--maroon)">The collection is being curated</div><h2>Coming soon.</h2><p style="max-width:520px;margin:0 auto 24px;color:var(--muted)">This space is intentionally empty for now. New pieces will appear here as the collection is curated. For purchase enquiries, please call <a href="tel:6376275637" class="text-link">6376275637</a>.</p><a class="btn" href="contact.html">Enquire with us</a></div>`; return; }
  grid.innerHTML = filtered.map(p => `<article class="product-card"><button class="wishlist-btn ${isWishlisted(p.id) ? 'saved' : ''}" data-wishlist="${escapeAttr(p.id)}" aria-label="${isWishlisted(p.id) ? 'Remove from wishlist' : 'Save to wishlist'}">${isWishlisted(p.id) ? '♥' : '♡'}</button><a class="product-link" href="/products/${encodeURIComponent(p.slug)}"><img src="${escapeAttr(p.images?.[0] || 'assets/product-placeholder.svg')}" alt="${escapeHtml(p.imageAlts?.[0] || `${p.name} — ${p.category}`)}" width="900" height="1125" loading="lazy" decoding="async"><div class="pcopy"><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.category)}</p><div class="price">${money(p.price)}</div><span class="text-link">View piece ↗</span></div></a></article>`).join('');
  $$('[data-wishlist]').forEach(b => b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); toggleWishlist(b.dataset.wishlist); renderProducts(cat); }));
}
async function renderSearch(q) {
  const box = $('.search-results'); if (!box) return;
  q = q.trim().toLowerCase();
  if (!q) { box.innerHTML = '<p style="color:var(--muted)">Search the collection by name or category.</p>'; return; }
  let found = products.filter(p => `${p.name} ${p.category} ${p.description || ''}`.toLowerCase().includes(q)).slice(0, 8);
  if (!found.length) {
    try { const r = await fetch(`/api/products?limit=8&q=${encodeURIComponent(q)}`, { cache: 'no-store' }); if (r.ok) { const data = await r.json(); found = (data.items || data).slice(0, 8); } } catch {}
  }
  box.innerHTML = found.length ? found.map(p => `<a href="/products/${encodeURIComponent(p.slug)}" class="search-result" data-search-id="${escapeAttr(p.slug)}"><span>${escapeHtml(p.name)}</span><span style="color:var(--muted)">${money(p.price)}</span></a>`).join('') : '<p style="color:var(--muted)">No matching pieces yet.</p>';
}
function escapeHtml(s) { return String(s).replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c])); }
function escapeAttr(s) { return escapeHtml(s).replace(/`/g, '&#96;'); }

function initContact() {
  const f = $('#contactForm'); if (!f) return;
  let started = Date.now();
  const stamp = f.querySelector('[name="form_started_at"]'); if (stamp) stamp.value = String(started);
  f.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = f.querySelector('button'); btn.disabled = true;
    try {
      const r = await fetch('/api/contact', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(new FormData(f))) });
      const j = await r.json(); if (!r.ok) throw Error(j.error || 'Unable to send');
      f.reset(); if (stamp) stamp.value = String(Date.now()); toast('Thank you. We will be in touch shortly.'); window.gtag?.('event', 'generate_lead', { method: 'contact_form' }); window.fbq?.('track', 'Lead');
    } catch (err) { toast(err.message); } finally { btn.disabled = false; }
  });
}

function initHeroSlideshow() {
  const slides = $$('.hero-slide'), dots = $$('.hero-dot'), hero = $('.hero'), pause = $('.hero-pause');
  if (slides.length < 2) return;
  let current = 0, timer = null, paused = false;
  const show = n => { current = (n + slides.length) % slides.length; slides.forEach((el, i) => el.classList.toggle('is-active', i === current)); dots.forEach((el, i) => el.classList.toggle('is-active', i === current)); };
  const stop = () => { if (timer) { clearInterval(timer); timer = null; } };
  const start = () => { stop(); if (paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return; timer = setInterval(() => show(current + 1), 5600); };
  const setPaused = value => { paused = value; pause?.setAttribute('aria-pressed', paused ? 'true' : 'false'); pause?.setAttribute('aria-label', paused ? 'Resume editorial slideshow' : 'Pause editorial slideshow'); pause?.classList.toggle('is-paused', paused); if (paused) stop(); else start(); };
  dots.forEach((d, i) => d.addEventListener('click', () => { show(i); start(); }));
  pause?.addEventListener('click', () => setPaused(!paused));
  hero?.addEventListener('focusin', stop); hero?.addEventListener('focusout', e => { if (!hero.contains(e.relatedTarget)) start(); });
  hero?.addEventListener('touchstart', () => setPaused(true), { passive: true });
  document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());
  show(0); start();
}

async function initPage() {
  await Promise.all([loadPublicConfig(), loadRates()]);
  initHeroSlideshow(); initGlobal(); initContact();
}
document.addEventListener('DOMContentLoaded', initPage);
